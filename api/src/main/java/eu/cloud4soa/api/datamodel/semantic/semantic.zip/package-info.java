@XmlJavaTypeAdapter(value=URIAdapter.class,type=URI.class)
package eu.cloud4soa.api.datamodel.semantic;

import eu.cloud4soa.api.datamodel.frontend.xmladapter.URIAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

