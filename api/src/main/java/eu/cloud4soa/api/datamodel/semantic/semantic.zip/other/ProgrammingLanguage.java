/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.cloud4soa.api.datamodel.semantic.other;

import com.viceversatech.rdfbeans.annotations.RDF;
import com.viceversatech.rdfbeans.annotations.RDFBean;
import com.viceversatech.rdfbeans.annotations.RDFSubject;
import eu.cloud4soa.api.datamodel.semantic.Thing;

/**
 *
 * @author vins
 */
@RDFBean("http://www.cloud4soa.eu/v0.1/other#ProgrammingLanguage")
public class ProgrammingLanguage extends Thing{
    
    	private java.lang.String version;
        private java.lang.String title;
        
        @Override
        @RDFSubject(prefix="http://www.cloud4soa.eu/v0.1/other#ProgrammingLanguage/")
        public String getUriId() {
                return super.getUriId();
        }
        
        @RDF("http://www.cloud4soa.eu/v0.1/other#hasVersion")
	public java.lang.String getVersion() {
		return version;
	}
	
	public void setVersion( java.lang.String version ) {
		this.version = version;
	}
        
        @RDF("http://purl.org/dc/terms/title")
	public java.lang.String getitle() {
		return title;
	}
	
	public void setTitle( java.lang.String title ) {
		this.title = title;
	}
}
